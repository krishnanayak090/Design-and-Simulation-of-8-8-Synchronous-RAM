# 8x8 Synchronous RAM in Verilog

## 🧠 Project Overview
This project implements an 8x8 (8-address, 8-bit data) synchronous RAM module in Verilog. It supports:
- Synchronous Write with `write_enable`
- Synchronous Read with `read_enable`
- Asynchronous Reset

## 📁 Files Included
- `ram_8x8.v`: RAM module
- `tb_ram_8x8.v`: Testbench (3 writes + 3 reads)
- `dump.vcd`: (Generated during simulation)

## ▶️ How to Run (Icarus Verilog)
```bash
iverilog -o ram_test ram_8x8.v tb_ram_8x8.v
vvp ram_test
gtkwave dump.vcd
```

## 📷 Expected Output
You should see:
```
Address 1 -> 0xA5
Address 2 -> 0x3C
Address 4 -> 0xF0
Reads return the same values as written.
```

## 📌 Author
Vankudothu Krishna — ECE Final Year
